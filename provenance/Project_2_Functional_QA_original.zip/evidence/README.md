Screenshots copied from the original AI-assisted metadata audit dated 24 November 2026. They are historical evidence, not new captures. Review third-party content before public redistribution.
